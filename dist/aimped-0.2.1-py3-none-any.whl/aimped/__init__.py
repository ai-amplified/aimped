from aimped.version import __version__
